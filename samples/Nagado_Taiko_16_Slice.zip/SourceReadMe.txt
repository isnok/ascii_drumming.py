source samples:

http://www.freesound.org/people/whatsanickname4u/sounds/95624/

license:

http://creativecommons.org/licenses/by/3.0/


changes:

denoise, pitch stretching to create variations 

